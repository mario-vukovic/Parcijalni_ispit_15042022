﻿using Ispit.Konzola;
using Ispit.Model;
using System;
using System.Collections;
using System.Collections.Generic;

namespace Ispit.Konzola
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Ucenik> ucenici = new List<Ucenik>();
            Console.WriteLine("Zapocnite unos ucenikovih podataka\n==================================");
            Ucenik ucenik = new Ucenik();

            for (int i = 0; i < 3; i++)
            {
                ucenik = UpisPodataka();
                ucenici.Add(ucenik);

                if (i < 2)
                {
                    Console.WriteLine("\nUnesite sljedeceg ucenika\n==========================");
                }

            }

            foreach (var item in ucenici)
            {
                var print = (Ucenik)item;
                IspisPodatakaUcenika(print);
            }

        }

        static Ucenik UpisPodataka()
        {
            Ucenik ucenik = new Ucenik();
            ucenik.Ime = DohvatiTekstOdKorisnika("Unesite ime ucenika: ");
            ucenik.Prezime = DohvatiTekstOdKorisnika("Unesite prezime ucenika: ");
            ucenik.DatumRodjenja = DateTime.Parse(DohvatiTekstOdKorisnika("Unesite datum rodjenja ucenika: "));
            ucenik.Prosjek = DohvatiProsjekOdKorisnika("Unesite prosjek ocjena ucenika: ");
            return ucenik;
        }

        static void IspisPodatakaUcenika(Ucenik ucenik)
        {
            string datumRodjenja = ucenik.DatumRodjenja.ToString("dd.MM.yyyy" + '.');
            Console.Write("\nUcenikovi podaci\n======================\nIme: {0}\nPrezime: {1}\nDatum rodjenja: {2}\nProsjek ocjena: {3}\n",
                ucenik.Ime, ucenik.Prezime, datumRodjenja, ucenik.Prosjek);
            ucenik.Starost();
            ucenik.IspisProsjeka();
        }

        static double DohvatiProsjekOdKorisnika(string poruka)
        {
            double broj = default;
            bool nastaviUnos = true;
            while (nastaviUnos)
            {
                Console.WriteLine(poruka);
                string unos = Console.ReadLine();

                if (double.TryParse(unos, out broj))
                {
                    nastaviUnos = false;
                }
            }
            return broj;
        }

        static string DohvatiTekstOdKorisnika(string poruka)
        {
            Console.WriteLine(poruka);
            return Console.ReadLine();
        }
    }
}
